package com.marcosvidolin.b2cdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B2cdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(B2cdemoApplication.class, args);
	}

}
