package com.marcosvidolin.b2cdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B2cdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
