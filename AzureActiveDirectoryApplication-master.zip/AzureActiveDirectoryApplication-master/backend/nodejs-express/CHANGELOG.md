# CHANGELOG

## 2020-03-21

* Switch to using the tenant domain name for the tenant ID in [config.js](config.js).
* Update README to reflect current state of sample and the articles referenced on [docs.microsoft.com](https://docs.microsoft.com/azure/active-directory-b2c).

## 2020-03-04

* Dependencies updated.
* Configuration parameters separated.
* README improved.
* ES6 conventions introduced.
