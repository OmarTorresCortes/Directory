# CHANGELOG

## 5/04/2020

* Updated to msal-angular 1.0.0.
* Updated to msal.js 1.3.0.
* Added error handling for password reset flow.

## 3/31/2020

* Updated Angular 8 to Angular 9.
* Added a new route protected by MSALGuard.
* Added Angular Factory for configuration objects.
* Reorganized configuration file and added clarifications.
* Minor changes on README.md.

## 2/20/2020

* Initial version of sample application and related files.
