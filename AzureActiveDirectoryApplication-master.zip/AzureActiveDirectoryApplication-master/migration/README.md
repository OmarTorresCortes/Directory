# User Migration

This is a migration application to import users from a legacy IdP to the Azure AD B2C.

## References

(Creating a new user in Azure AD)[https://docs.microsoft.com/en-us/powershell/azure/active-directory/new-user-sample?view=azureadps-2.0]
